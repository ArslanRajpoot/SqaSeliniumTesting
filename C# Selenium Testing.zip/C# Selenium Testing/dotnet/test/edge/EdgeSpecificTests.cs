using NUnit.Framework;

namespace OpenQA.Selenium.Edge
{
    [TestFixture]
    public class EdgeSpecificTests : DriverTestFixture
    {
    }
}
