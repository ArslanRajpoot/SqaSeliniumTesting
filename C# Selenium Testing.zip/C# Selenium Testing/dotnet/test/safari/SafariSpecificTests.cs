using NUnit.Framework;

namespace OpenQA.Selenium.Safari
{
    [TestFixture]
    public class SafariSpecificTests : DriverTestFixture
    {
    }
}
