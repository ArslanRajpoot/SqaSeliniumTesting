using NUnit.Framework;

namespace OpenQA.Selenium.Opera
{
    [TestFixture]
    public class OperaSpecificTests : DriverTestFixture
    {
    }
}
