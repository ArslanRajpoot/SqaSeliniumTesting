namespace OpenQA.Selenium
{
    public enum Browser
    {
        All, 
        IE,
        Edge,
        Firefox, 
        Safari, 
        Chrome,
        Opera,
        Remote, 
    }
}
