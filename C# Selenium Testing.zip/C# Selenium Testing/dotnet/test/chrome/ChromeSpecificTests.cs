﻿using NUnit.Framework;

namespace OpenQA.Selenium.Chrome
{
    [TestFixture]
    public class ChromeSpecificTests : DriverTestFixture
    {
    }
}
