selenium.webdriver.remote.errorhandler
======================================

.. automodule:: selenium.webdriver.remote.errorhandler
