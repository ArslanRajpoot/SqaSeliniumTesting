selenium.webdriver.common.desired_capabilities
==============================================

.. automodule:: selenium.webdriver.common.desired_capabilities
