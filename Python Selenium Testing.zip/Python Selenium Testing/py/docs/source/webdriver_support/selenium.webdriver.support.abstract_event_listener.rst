selenium.webdriver.support.abstract_event_listener
==================================================

.. automodule:: selenium.webdriver.support.abstract_event_listener
