selenium.webdriver.support.color
================================

.. automodule:: selenium.webdriver.support.color
