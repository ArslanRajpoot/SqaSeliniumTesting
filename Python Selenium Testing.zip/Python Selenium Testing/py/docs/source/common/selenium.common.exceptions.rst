selenium.common.exceptions
==========================

.. automodule:: selenium.common.exceptions
