selenium.webdriver.firefox.firefox_profile
==========================================

.. automodule:: selenium.webdriver.firefox.firefox_profile
