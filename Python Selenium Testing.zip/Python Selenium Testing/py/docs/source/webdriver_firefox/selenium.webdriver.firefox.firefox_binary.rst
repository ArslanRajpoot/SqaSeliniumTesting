selenium.webdriver.firefox.firefox_binary
=========================================

.. automodule:: selenium.webdriver.firefox.firefox_binary
