selenium.webdriver.firefox.options
==================================

.. automodule:: selenium.webdriver.firefox.options
