selenium.webdriver.firefox.extension_connection
===============================================

.. automodule:: selenium.webdriver.firefox.extension_connection
