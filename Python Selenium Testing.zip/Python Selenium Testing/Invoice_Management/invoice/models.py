from django.db import models


class Register(models.Model):
    company = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=255)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email_address = models.EmailField()
    street_house_number = models.CharField(max_length=255)
    zip_code_city = models.CharField(max_length=100)
    country = models.CharField(max_length=25)

    def __str__(self):
        return self.username


class PersonalData(models.Model):

    full_name = models.CharField(max_length=255)
    sur_name = models.CharField(max_length=255)
    roll = models.CharField(max_length=100)

    def __str__(self):
        return self.full_name


class Address(models.Model):
    street_house_number = models.CharField(max_length=255)
    zip_code_city = models.CharField(max_length=100)
    land = models.CharField(max_length=25)

    def __str__(self):
        return self.land


class Contact(models.Model):
    first_name = models.CharField(max_length=255)
    sur_name = models.CharField(max_length=255)
    # telephone = models.CharField(max_length=50)
    car = models.CharField(max_length=100)
    email = models.EmailField()

    def __str__(self):
        return self.first_name
