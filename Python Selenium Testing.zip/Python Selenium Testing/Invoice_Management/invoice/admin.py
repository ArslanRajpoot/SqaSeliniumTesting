from django.contrib import admin
from . import models
# Register your models here.
admin.site.register(models.Register)
admin.site.register(models.PersonalData)
admin.site.register(models.Address)
admin.site.register(models.Contact)