from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from . import models
# Create your views here.


# @login_required(login_url='/login/')
def register(request):

    if request.method == "POST":
        for register_obj in models.Register.objects.all():
            if register_obj.username == request.POST["user_name"]:
                return render(request, "Register.html", {"message": request.POST["user_name"] + " already exits"})
            if register_obj.email_address == request.POST["email"]:
                return render(request, 'Register.html', {"message": request.POST["email"] + "aready exits"})
        models.Register(company=request.POST["company"], username=request.POST["user_name"], password=request.POST["password"], first_name=request.POST["first_name"], last_name=request.POST["last_name"], email_address=request.POST["email"], street_house_number=request.POST["street"] + ',' + request.POST["house_number"], zip_code_city=request.POST["zip_code"] + ',' + request.POST["city"], country=request.POST["select_country"]).save()
        redirect(login)
        # return HttpResponse("it is registered")
        return redirect(login)
    return render(request, "Register.html")


def login(request):
    if request.method == "POST":
        for login_obj in models.Register.objects.all():
            if login_obj.username == request.POST["user_name"] and login_obj.password == request.POST["password"]:
                return redirect(add_profile)
            else:
                # return render(request, "login.html", {"message": "UserName and Password does not Match"})
                return redirect(add_profile)
    return render(request, "login.html")


# @login_required(login_url="/login/")
def launch_pad(request):
    return render(request, "Launch_pad.html")


def profile(request):
    return render(request, "profiles.html", {"new_profile": models.PersonalData.objects.all(), "admin_address": models.Address.objects.all()})


def add_profile(request):
    if request.method == "POST":
        models.PersonalData(full_name=request.POST["full_name"], sur_name=request.POST["surname"], roll=request.POST["roll"]).save()
        models.Address(street_house_number=request.POST["street"] + ',' + request.POST["house_number"], zip_code_city=request.POST["post_code"] + ',' + request.POST["town"], land=request.POST["land"]).save()
        models.Contact(first_name=request.POST["cf_name"], sur_name=request.POST["cs_name"], car=request.POST["c_car"], email=request.POST["c_email"]).save()
        return redirect(profile)
    return render(request, "Add_profile.html", {"new_profile": models.PersonalData.objects.all()})

