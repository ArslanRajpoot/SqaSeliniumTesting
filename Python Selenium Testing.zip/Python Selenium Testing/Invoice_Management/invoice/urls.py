from django.urls import path
from . import views

urlpatterns = [
  path("", views.login, name="login"),
  path('register/', views.register, name="register"),
  path('register/login/', views.login, name="reqister_login"),
  path("login/launchpad/", views.launch_pad, name="launchpad"),
  path("login/add_profile", views.add_profile, name="add_profile"),
  path("login/profile", views.profile, name="profile")

]
